<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>CURA_TestSuite_1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>0fa8494a-ce9e-4051-b469-cbf2b1d8923b</testSuiteGuid>
   <testCaseLink>
      <guid>1e014216-4b30-4135-81ae-fbf8ae7fe4de</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CURA/TC_CURA_Website_Validation_001</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>7a1a1821-5ba1-466d-ab7b-8760a5eda1c4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CURA/TC_CURA_Login_002</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>ff1b36bf-7192-41b7-ae2d-b80d66591c24</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/TestData_CURA_Login/CURA_excel</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>ff1b36bf-7192-41b7-ae2d-b80d66591c24</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>username</value>
         <variableId>57761fe0-521c-4231-acca-0440652dd7d4</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>ff1b36bf-7192-41b7-ae2d-b80d66591c24</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>password</value>
         <variableId>589a3c9e-6dc5-44f8-9e28-106bc2f0d5d3</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>ac4f2667-49cc-4767-9ef2-49da506d453b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CURA/TC_CURA_MakeApointment_003</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
